//
//  command.h
//  P1
//
//  Created by Jun Wei Wang on 2022-10-01.
//

#ifndef command_h
#define command_h

#include <stdio.h>
#include <ncurses.h>

int getUserInput(void);

#endif /* command_h */
