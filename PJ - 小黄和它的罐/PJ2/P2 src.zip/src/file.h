//
//  file.h
//  PJ2
//
//  Created by Jun Wei Wang on 2022-12-23.
//

#ifndef file_h
#define file_h

#include <stdio.h>
#include <stdlib.h>
#include "constants.h"

void writeStratFile(int *arr);
int *readStratFile(char *c);

#endif /* file_h */
